
let wins = 0;
let losses = 0;
let draws = 0;

function play(userChoice) {
  const choices = ['rock', 'paper', 'scissors'];
  const computerChoice = choices[Math.floor(Math.random() * 3)];

  let result = '';
  if (userChoice === computerChoice) {
    result = "It's a draw!";
    draws++;
  } else if (
    (userChoice === 'rock' && computerChoice === 'scissors') ||
    (userChoice === 'paper' && computerChoice === 'rock') ||
    (userChoice === 'scissors' && computerChoice === 'paper')
  ) {
    result = 'You win! 🎉';
    wins++;
  } else {
    result = 'You lose! 😢';
    losses++;
  }

  document.getElementById('result').textContent = `You chose ${userChoice}, computer chose ${computerChoice}. ${result}`;
  updateScore();
}

function updateScore() {
  document.getElementById('score').textContent = `Wins: ${wins} | Losses: ${losses} | Draws: ${draws}`;
}

function resetScore() {
  wins = 0;
  losses = 0;
  draws = 0;
  updateScore();
  document.getElementById('result').textContent = '';
}
